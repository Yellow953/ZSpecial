<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2023. All right reserved by <a href="https://yellowtech.dev" target="_blank">YellowTech</a></p>
    </div>
</footer>
<!-- footer area end-->